<?php
header('Content-Type: application/json');
require_once('../middleware/auth.php');
require_once('../config/db.php');
require_once('../utils/response.php');

check_auth(); // Middleware call

$stmt = $conn->prepare("SELECT * FROM appointments ORDER BY date DESC LIMIT 10");
$stmt->execute();
$data = $stmt->fetchAll();

echo json_response(true, "Latest appointments", $data);
