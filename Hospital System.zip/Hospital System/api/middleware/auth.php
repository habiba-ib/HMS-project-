<?php
function check_auth() {
    $headers = getallheaders();
    if (!isset($headers['Authorization'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Missing Authorization header.']);
        exit;
    }

    $token = trim(str_replace("Bearer", "", $headers['Authorization']));

    // Fake token check for now (you can replace this with a DB lookup)
    if ($token !== 'your-hardcoded-token') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Invalid or expired token.']);
        exit;
    }

    return true;
}
