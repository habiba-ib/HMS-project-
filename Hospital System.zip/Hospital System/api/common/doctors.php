<?php
header('Content-Type: application/json');
require_once('../config/db.php');
require_once('../utils/response.php');

$stmt = $conn->query("SELECT * FROM doctor");
$data = $stmt->fetchAll();

echo json_response(true, "Doctors list", $data);
