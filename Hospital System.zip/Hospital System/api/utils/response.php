<?php
function json_response($success, $message, $data = []) {
    return json_encode([
        "success" => $success,
        "message" => $message,
        "data" => $data
    ]);
}
