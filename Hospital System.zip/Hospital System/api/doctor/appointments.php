<?php
header('Content-Type: application/json');
require_once('../middleware/auth.php');
require_once('../config/db.php');
require_once('../utils/response.php');

// Simulated token check — you'll connect this with real tokens later
check_auth();

// In a real system, you'd extract the doctor's ID from the token/session
$doctor_id = $_GET['doctor_id'] ?? null;

if (!$doctor_id) {
    echo json_response(false, "Missing doctor_id");
    exit;
}

$stmt = $conn->prepare("SELECT * FROM appointments WHERE doctor_id = ? ORDER BY date DESC");
$stmt->execute([$doctor_id]);
$data = $stmt->fetchAll();

echo json_response(true, "Doctor's appointments fetched successfully", $data);
