<?php
header('Content-Type: application/json');
require_once('../middleware/auth.php');
require_once('../config/db.php');
require_once('../utils/response.php');

check_auth();

$data = json_decode(file_get_contents("php://input"), true);

$appointment_id = $data['appointment_id'] ?? null;
$doctor_id = $data['doctor_id'] ?? null;
$prescription_text = trim($data['prescription'] ?? '');

if (!$appointment_id || !$doctor_id || !$prescription_text) {
    echo json_response(false, "All fields are required.");
    exit;
}

$stmt = $conn->prepare("INSERT INTO prescriptions (appointment_id, doctor_id, prescription_text, created_at) VALUES (?, ?, ?, NOW())");
$stmt->execute([$appointment_id, $doctor_id, $prescription_text]);

echo json_response(true, "Prescription saved successfully");
