<?php
header('Content-Type: application/json');

require_once('../config/db.php');
require_once('../utils/response.php');

$data = json_decode(file_get_contents("php://input"), true);
$email = trim($data['email'] ?? '');
$password = $data['password'] ?? '';

if (!$email || !$password) {
    echo json_response(false, "Email and password are required.");
    exit;
}

$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($password, $user['password'])) {
    // Generate a token (or use session if desired)
    $token = bin2hex(random_bytes(32));

    // Store token in DB or Redis (optional)
    echo json_response(true, "Login successful", [
        "token" => $token,
        "user" => [
            "id" => $user['id'],
            "name" => $user['name'],
            "role" => $user['role']
        ]
    ]);
} else {
    echo json_response(false, "Invalid credentials");
}
