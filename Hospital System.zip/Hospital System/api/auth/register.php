<?php
header('Content-Type: application/json');

require_once('../config/db.php');
require_once('../utils/response.php');

$data = json_decode(file_get_contents("php://input"), true);

$name = trim($data['name'] ?? '');
$email = trim($data['email'] ?? '');
$password = $data['password'] ?? '';
$role = $data['role'] ?? 'patient'; // patient/doctor/admin

if (!$name || !$email || !$password) {
    echo json_response(false, "All fields are required.");
    exit;
}

// Check if user exists
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);
if ($stmt->rowCount() > 0) {
    echo json_response(false, "Email is already registered.");
    exit;
}

// Insert new user
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
$stmt->execute([$name, $email, $hashedPassword, $role]);

echo json_response(true, "User registered successfully.");
