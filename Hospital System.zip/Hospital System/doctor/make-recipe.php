<?php
session_start();
include("../connection.php");

if (!isset($_SESSION["user"]) || $_SESSION["usertype"] != 'd') {
    header("location: ../login.php");
    exit;
}

$docid = $_SESSION["user"];
$appointment_id = $_GET['appoid'] ?? null;
$pid = $_GET['pid'] ?? null;

if ($_POST) {
    $medications = $_POST['medication'];
    $dosages = $_POST['dosage'];
    $instructions = $_POST['instructions'];

    $database->query("INSERT INTO recipe (appointment_id, docid, pid) VALUES ('$appointment_id', '$docid', '$pid')");
    $recipe_id = $database->insert_id;

    for ($i = 0; $i < count($medications); $i++) {
        $m = $medications[$i];
        $d = $dosages[$i];
        $ins = $instructions[$i];

        $database->query("INSERT INTO recipe_item (recipe_id, medication, dosage, instructions) 
                          VALUES ('$recipe_id', '$m', '$d', '$ins')");
    }

    header("location: appointment.php?action=recipe-added");
    exit;
}
?>

<form method="POST">
    <h2>Make Recipe</h2>
    <div id="med-list">
        <div class="med-block">
            <input type="text" name="medication[]" placeholder="Medication Name" required>
            <input type="text" name="dosage[]" placeholder="Dosage">
            <input type="text" name="instructions[]" placeholder="Instructions">
        </div>
    </div>
    <button type="button" onclick="addField()">+ Add More</button><br><br>
    <input type="submit" value="Save Recipe">
</form>

<script>
function addField() {
    const div = document.createElement('div');
    div.classList.add('med-block');
    div.innerHTML = `
        <input type="text" name="medication[]" placeholder="Medication Name" required>
        <input type="text" name="dosage[]" placeholder="Dosage">
        <input type="text" name="instructions[]" placeholder="Instructions">`;
    document.getElementById('med-list').appendChild(div);
}
</script>
