<?php
$servername = "localhost";
$username = "root";  
$password = ""; 
$dbname = "HMS"; 

$database = new mysqli($servername, $username, $password, $dbname);

if ($database->connect_error) {
    die("Database connection failed. : " . $database->connect_error);
}
?>

