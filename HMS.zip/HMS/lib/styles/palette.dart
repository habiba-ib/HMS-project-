import 'package:flutter/material.dart';

/// A palette of colors to be used in the app.
///
/// Colors taken from this fun palette:
/// https://lospec.com/palette-list/crayola84
///
/// Colors here are implemented as getters so that hot reloading works.
/// In practice, we could just as easily implement the colors
/// as `static const`. But this way the palette is more malleable:
/// we could allow players to customize colors, for example,
/// or even get the colors from the network.
class Palette {
  // Primary Colors
  final Color primary = const Color(0xFF0D77D6); // Main blue color
  final Color primaryLight = const Color(0xFF4A9DE3); // Lighter shade
  final Color primaryDark = const Color(0xFF0959A8); // Darker shade
  
  // Text Colors
  final Color textDark = Colors.white;
  final Color textLight = Colors.black;
  
  // Background Colors
  final Color background = Colors.white;
  final Color backgroundDark = const Color(0xFFF5F5F5);
  
  // Accent Colors
  final Color accent = const Color(0xFF0D77D6);
  final Color accentLight = const Color(0xFF4A9DE3);
  
  // Status Colors
  final Color success = Colors.green;
  final Color error = Colors.red;
  final Color warning = Colors.orange;
  final Color info = const Color(0xFF0D77D6);
  
  // Other UI Colors
  final Color divider = Colors.grey[300]!;
  final Color disabled = Colors.grey[400]!;
  final Color shadow = Colors.black.withOpacity(0.1);
  
  // Keep violet for backward compatibility
  final Color violet = const Color(0xFF0D77D6);

  Color get darkViolet => const Color(0xFF4531AC);
  Color get category => const Color(0xFFCFC8FF);
  Color get backgroundMain => const Color(0xffF8FAFF);
  Color get textFade => const Color(0xff878787);
  Color get backFade => const Color(0xffECEBFF);
  Color get notifColor => const Color(0xffCFC8FF);
  Color get congrasColor => const Color(0xff0B72AC);
  Color get trueWhite => const Color(0xffffffff);
  Color get mtn => const Color(0xffFECA05);
  Color get orange => const Color(0xffFF7900);
  Color get badge => const Color(0xfFCFC8FF);
  Color get doctorBack => const Color(0xfFCFC8FF);
  Color get welcomeBack => const Color(0xff372ee4);
}
