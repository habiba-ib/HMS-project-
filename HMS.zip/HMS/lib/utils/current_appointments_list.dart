const currentAppointmentsList = [
  {
    "name": "Dr. Aman Wins",
    "drImage": 'assets/images/doctor-placeholder.png',
    "label": '12:00 PM',
    "specialization": 'Cardiolist',
    "dotsImage": 'assets/icons/3-dots.png',
  },
  {
    "name": "Dr. Jonh Wins",
    "drImage": 'assets/images/doctor-placeholder.png',
    "label": '12:00 PM',
    "specialization": 'Cardiolist',
    "dotsImage": 'assets/icons/3-dots.png',
  },
  {
    "name": "Dr. Melisa Wins",
    "drImage": 'assets/images/doctor-placeholder.png',
    "label": '12:00 PM',
    "specialization": 'Cardiolist',
    "dotsImage": 'assets/icons/3-dots.png',
  },
  {
    "name": "Dr. Dilan Wins",
    "drImage": 'assets/images/doctor-placeholder.png',
    "label": '12:00 PM',
    "specialization": 'Cardiolist',
    "dotsImage": 'assets/icons/3-dots.png',
  },
];
