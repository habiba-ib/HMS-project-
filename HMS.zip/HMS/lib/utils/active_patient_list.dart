const activePatientList = [
  {
    "image": "assets/images/doctor-placeholder-appointment.png",
    "goTo": "home/patient-details"
  },
  {
    "image": "assets/images/doctor-placeholder-appointment.png",
    "goTo": "home/patient-details"
  },
  {
    "image": "assets/images/doctor-placeholder-appointment.png",
    "goTo": "home/patient-details"
  },
  {
    "image": "assets/images/doctor-placeholder-appointment.png",
    "goTo": "home/patient-details"
  },
  {
    "image": "assets/images/doctor-placeholder-appointment.png",
    "goTo": "home/patient-details"
  },
  {
    "image": "assets/images/doctor-placeholder-appointment.png",
    "goTo": "home/patient-details"
  },
  {
    "image": "assets/images/doctor-placeholder-appointment.png",
    "goTo": "home/patient-details"
  },
];
