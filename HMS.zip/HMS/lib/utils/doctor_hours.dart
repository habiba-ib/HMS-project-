const doctorHours= [
  {
    "hour": "10:00AM",
  },
  {
    "hour": "08:00AM",
  },
  {
    "hour": "11:00AM",
  },
  {
    "hour": "01:00AM",
  },
  {
    "hour": "10:00AM",
  },
  {
    "hour": "08:00AM",
  },
  {
    "hour": "11:00AM",
  },
  {
    "hour": "01:00AM",
  },
  {
    "hour": "10:00AM",
  },
  {
    "hour": "08:00AM",
  },
  {
    "hour": "11:00AM",
  },
  {
    "hour": "01:00AM",
  },
];
