import 'package:flutter/material.dart';
import 'package:healthcare/styles/palette.dart';
import 'package:provider/provider.dart';

class CustomMaterialButton extends StatefulWidget {
  final Function()? onPressed;
  final bool isActive;
  final IconData icon;
  const CustomMaterialButton({
    super.key,
    required this.onPressed,
    required this.isActive,
    required this.icon,
  });

  @override
  State<CustomMaterialButton> createState() => _CustomMaterialButtonState();
}

class _CustomMaterialButtonState extends State<CustomMaterialButton> {
  @override
  Widget build(BuildContext context) {
    final palette = context.watch<Palette>();

    return MaterialButton(
      highlightColor: Colors.transparent,
      splashColor: Colors.transparent,
      onPressed: widget.onPressed,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: widget.isActive
            ? BoxDecoration(
                color: palette.violet.withAlpha(26), // 0.1 opacity
                borderRadius: BorderRadius.circular(12),
              )
            : null,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              widget.icon,
              color: widget.isActive ? palette.violet : Colors.grey,
              size: 28,
            ),
            if (widget.isActive)
              Container(
                margin: const EdgeInsets.only(top: 4),
                width: 4,
                height: 4,
                decoration: BoxDecoration(
                  color: palette.violet,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
