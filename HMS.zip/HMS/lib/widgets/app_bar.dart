import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:healthcare/models/user.dart';
import 'package:healthcare/notifiers/user_notifier.dart';
import 'package:healthcare/styles/palette.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';

class CustomAppBar extends StatelessWidget {
  const CustomAppBar(
      {super.key,
      this.topSpacing = 0,
      required this.radius,
      this.goTo,
      this.top,
      this.left,
      this.width,
      this.height,
      required this.title,
      this.name,
      required this.horizontalSpacing,
      required this.fontSize,
      required this.spacing,
      required this.bottomSpacing,
      this.notifBtn,
      this.accountBtn,
      required this.positionedWidget,
      required this.mainAxisAlignment,
      this.widthFactor = .7,
      this.containerHeight,
      this.introText,
      this.toPadding = 0});

  /// Spacing from the top of the phone to the stack
  final double toPadding;
  final double topSpacing;
  final double radius;

  /// Where to go when we click on back button(or icon )
  final String? goTo;

  /// Values for the positionned element
  final double? top;
  final double? left;
  final double? width;
  final double widthFactor;
  final double? height;
  final double? containerHeight;

  /// Title after the back icon
  final String title;

  /// Text after the notif icon
  final String? introText;

  /// Name of the client if the page needs it
  final String? name;

  /// Spacing between back button and [title]
  final double horizontalSpacing;

  /// Fontsize of [title]
  final double fontSize;

  /// Spacing between back button and the phone's border
  final double spacing;

  /// Spacing between [positionedWidget]  and the bottom of the stack
  final double bottomSpacing;

  ///Icon of any notification button
  final Widget? notifBtn;

  ///Icon of any account button
  final Widget? accountBtn;

  final Widget positionedWidget;
  final MainAxisAlignment mainAxisAlignment;

  static final _log = Logger('app_bar.dart');

  @override
  Widget build(BuildContext context) {
    final palette = context.watch<Palette>();
    final Size size = MediaQuery.of(context).size;
    User user = context.watch<UserNotifier>().getUser();

    return Stack(
      children: [
        Container(
          padding: EdgeInsets.only(top: toPadding),
          margin: EdgeInsets.only(top: topSpacing),
          height: 120,
          decoration: BoxDecoration(
            shape: BoxShape.rectangle,
            color: palette.violet,
            borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(radius),
                bottomRight: Radius.circular(radius)),
          ),
        ),
        Positioned(
          top: 25,
          left: 10,
          right: 10,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      InkWell(
                        onTap: () {
                          goTo == null
                              ? GoRouter.of(context).pop()
                              : GoRouter.of(context).go(goTo!);
                        },
                        child: Container(
                          padding: const EdgeInsets.all(0),
                          child: Icon(
                            Icons.arrow_back_ios_new_sharp,
                            size: 15,
                            color: palette.textDark,
                          ),
                        ),
                      ),
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          _log.info("Going to notifications");
                          GoRouter.of(context).go('/home/notifications');
                        },
                        child: Container(
                          width: MediaQuery.of(context).size.width * 0.25,
                          decoration: const BoxDecoration(
                            shape: BoxShape.rectangle,
                          ),
                          child: const Padding(
                            padding: EdgeInsets.all(0.0),
                            child: Image(
                              image: AssetImage('assets/icons/notification.png'),
                            ),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          GoRouter.of(context).go('/home/profile');
                        },
                        child: Container(
                          decoration: const BoxDecoration(
                            shape: BoxShape.rectangle,
                          ),
                          child: const Padding(
                            padding: EdgeInsets.all(0.0),
                            child: Image(
                              width: 55,
                              image: AssetImage('assets/icons/account.png'),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}