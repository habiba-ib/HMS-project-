import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:healthcare/widgets/custom_bottom_button.dart';
import 'package:healthcare/styles/palette.dart';
import 'package:provider/provider.dart';

class CustomBottomNavBar extends StatefulWidget {
  final int page;
  const CustomBottomNavBar({super.key, required this.page});

  @override
  State<CustomBottomNavBar> createState() => _CustomBottomNavBarState();
}

class _CustomBottomNavBarState extends State<CustomBottomNavBar> {
  @override
  Widget build(BuildContext context) {
    final palette = context.watch<Palette>();
    int currentTab = widget.page;

    return Container(
      height: 90,
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withAlpha(51), // 0.2 opacity
            spreadRadius: 1,
            blurRadius: 5,
            offset: const Offset(0, -1),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          Expanded(
            child: CustomMaterialButton(
              icon: Icons.home_outlined,
              onPressed: () {
                setState(() {
                  currentTab = 0;
                  GoRouter.of(context).replace("/home");
                });
              },
              isActive: currentTab == 0,
            ),
          ),
          Expanded(
            child: CustomMaterialButton(
              icon: Icons.calendar_month_outlined,
              onPressed: () {
                setState(() {
                  currentTab = 1;
                  GoRouter.of(context).replace("/home/history");
                });
              },
              isActive: currentTab == 1,
            ),
          ),
          Expanded(
            child: CustomMaterialButton(
              icon: Icons.health_and_safety_rounded,
              onPressed: () {
                setState(() {
                  currentTab = 2;
                  GoRouter.of(context).replace("/home/specialties");
                });
              },
              isActive: currentTab == 2,
            ),
          ),
          Expanded(
            child: CustomMaterialButton(
              icon: Icons.person_outline,
              onPressed: () {
                setState(() {
                  currentTab = 3;
                  GoRouter.of(context).replace('/home/profile');
                });
              },
              isActive: currentTab == 3,
            ),
          ),
        ],
      ),
    );
  }
}
