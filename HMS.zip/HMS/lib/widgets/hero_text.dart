import 'package:flutter/material.dart';
import 'package:healthcare/styles/palette.dart';
import 'package:provider/provider.dart';

class HeroText extends StatelessWidget {
  final String name;

  const HeroText({super.key, required this.name});

  @override
  Widget build(BuildContext context) {
    final palette = context.watch<Palette>();
    return Column(
      children: [
        Text(
          "Hi, Welcome Back,",
          style: TextStyle(fontSize: 14, color: palette.trueWhite),
        ),
        Text(
          name,
          style: TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 18,
              color: palette.textDark),
        ),
      ],
    );
  }
}
