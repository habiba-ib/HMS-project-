import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:healthcare/styles/palette.dart';
import 'package:healthcare/notifiers/user_notifier.dart';
import 'package:healthcare/widgets/search_input.dart';
import 'package:healthcare/widgets/bottom_nav_bar.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';
import 'package:healthcare/screens/specialties/doctors_list_page.dart';

class SpecialtiesPage extends StatefulWidget {
  const SpecialtiesPage({super.key});

  @override
  State<SpecialtiesPage> createState() => _SpecialtiesPageState();
}

class _SpecialtiesPageState extends State<SpecialtiesPage> {
  static final _log = Logger('specialties_page.dart');
  String _searchQuery = '';

  // قائمة التخصصات
  static final List<Map<String, dynamic>> specialtiesList = [
    {
      "name": "Cardiology",
      "icon": Icons.favorite_border_rounded,
      "doctorsCount": 12,
      "color": const Color(0xFFFF6B6B),
    },
    {
      "name": "Neurology",
      "icon": Icons.psychology_rounded,
      "doctorsCount": 8,
      "color": const Color(0xFF4ECDC4),
    },
    {
      "name": "Pediatrics",
      "icon": Icons.baby_changing_station_rounded,
      "doctorsCount": 15,
      "color": const Color(0xFFFFD93D),
    },
    {
      "name": "Dermatology",
      "icon": Icons.face_retouching_natural_rounded,
      "doctorsCount": 10,
      "color": const Color(0xFF95E1D3),
    },
    {
      "name": "Orthopedics",
      "icon": Icons.accessible_rounded,
      "doctorsCount": 9,
      "color": const Color(0xFFFF8B94),
    },
    {
      "name": "Ophthalmology",
      "icon": Icons.remove_red_eye_rounded,
      "doctorsCount": 7,
      "color": const Color(0xFF6C5CE7),
    },
    {
      "name": "Dentistry",
      "icon": Icons.cleaning_services_rounded,
      "doctorsCount": 11,
      "color": const Color(0xFF00B894),
    },
    {
      "name": "Gynecology",
      "icon": Icons.woman_rounded,
      "doctorsCount": 9,
      "color": const Color(0xFFFF9FF3),
    },
    {
      "name": "ENT",
      "icon": Icons.hearing_rounded,
      "doctorsCount": 6,
      "color": const Color(0xFF54A0FF),
    },
    {
      "name": "Gastroenterology",
      "icon": Icons.sanitizer_rounded,
      "doctorsCount": 8,
      "color": const Color(0xFFFECA57),
    },
  ];

  List<Map<String, dynamic>> get _filteredSpecialties {
    if (_searchQuery.isEmpty) {
      return specialtiesList;
    }
    return specialtiesList.where((specialty) {
      return specialty['name'].toString().toLowerCase().contains(_searchQuery.toLowerCase());
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final palette = context.watch<Palette>();
    final user = context.watch<UserNotifier>().getUser();

    return Scaffold(
      backgroundColor: palette.backgroundMain,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Section
              Container(
                padding: const EdgeInsets.only(
                  left: 21,
                  right: 21,
                  top: 16,
                  bottom: 20,
                ),
                decoration: BoxDecoration(
                  color: palette.violet,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              "Medical",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              "Specialties",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            IconButton(
                              onPressed: () {
                                _log.info("Going to notifications");
                                GoRouter.of(context).go('/home/notifications');
                              },
                              icon: const Icon(
                                Icons.notifications_outlined,
                                color: Colors.white,
                                size: 26,
                              ),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(),
                            ),
                            const SizedBox(width: 16),
                            GestureDetector(
                              onTap: () => GoRouter.of(context).go('/home/profile'),
                              child: CircleAvatar(
                                radius: 18,
                                backgroundImage: AssetImage(user.image),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    Container(
                      height: 45,
                      width: double.infinity,
                      child: SearchInput(
                        placeholder: "Search specialties...",
                        handleSearchAction: (value) {
                          setState(() {
                            _searchQuery = value;
                          });
                          _log.info("Searching for specialties: $value");
                        },
                      ),
                    ),
                  ],
                ),
              ),

              // Specialties Grid Section
              Padding(
                padding: EdgeInsets.fromLTRB(24, 32, 24, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "All Specialties",
                          style: TextStyle(
                            color: palette.textDark,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            color: palette.violet.withAlpha(13),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            "View All",
                            style: TextStyle(
                              color: palette.violet,
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 24),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                        childAspectRatio: 1.1,
                      ),
                      itemCount: _filteredSpecialties.length,
                      itemBuilder: (context, index) {
                        final specialty = _filteredSpecialties[index];
                        return GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => DoctorsListPage(
                                  specialtyName: specialty["name"],
                                  specialtyIcon: specialty["icon"],
                                  specialtyColor: specialty["color"],
                                ),
                              ),
                            );
                          },
                          child: Container(
                            padding: EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Colors.white,
                                  palette.violet.withAlpha(13),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: palette.violet.withAlpha(26),
                                  blurRadius: 15,
                                  offset: const Offset(0, 8),
                                ),
                              ],
                              border: Border.all(
                                color: palette.violet.withAlpha(26),
                                width: 1,
                              ),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  padding: EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: specialty['color'].withAlpha(13),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Icon(
                                    specialty['icon'],
                                    color: specialty['color'],
                                    size: 32,
                                  ),
                                ),
                                SizedBox(height: 12),
                                Text(
                                  specialty['name'],
                                  style: TextStyle(
                                    color: palette.textDark,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                SizedBox(height: 4),
                                Text(
                                  "${specialty['doctorsCount']} Doctors",
                                  style: TextStyle(
                                    color: palette.textFade,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: const CustomBottomNavBar(
        page: 2,
      ),
    );
  }
} 