import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:healthcare/styles/palette.dart';
import 'package:healthcare/widgets/bottom_nav_bar.dart';
import 'package:healthcare/widgets/search_input.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';

class DoctorsListPage extends StatefulWidget {
  final String specialtyName;
  final IconData specialtyIcon;
  final Color specialtyColor;

  const DoctorsListPage({
    super.key,
    required this.specialtyName,
    required this.specialtyIcon,
    required this.specialtyColor,
  });

  @override
  State<DoctorsListPage> createState() => _DoctorsListPageState();
}

class _DoctorsListPageState extends State<DoctorsListPage> {
  static final _log = Logger('doctors_list_page.dart');
  String _searchQuery = '';

  // Temporary list of doctors - you can replace this with real data
  final List<Map<String, dynamic>> doctorsList = [
    {
      "name": "Dr. Ahmed Mohamed",
      "image": "assets/images/doctor1.png",
      "rating": 4.8,
      "experience": "15 years",
      "patients": 1200,
    },
    {
      "name": "Dr. Sarah Ali",
      "image": "assets/images/doctor2.png",
      "rating": 4.9,
      "experience": "12 years",
      "patients": 980,
    },
    {
      "name": "Dr. Mohamed Hassan",
      "image": "assets/images/doctor3.png",
      "rating": 4.7,
      "experience": "10 years",
      "patients": 850,
    },
  ];

  List<Map<String, dynamic>> get _filteredDoctors {
    if (_searchQuery.isEmpty) {
      return doctorsList;
    }
    return doctorsList.where((doctor) {
      return doctor['name'].toString().toLowerCase().contains(_searchQuery.toLowerCase());
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final palette = context.watch<Palette>();
    final Size size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: palette.backgroundMain,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Section
              Container(
                padding: const EdgeInsets.only(
                  left: 21,
                  right: 21,
                  top: 16,
                  bottom: 20,
                ),
                decoration: BoxDecoration(
                  color: widget.specialtyColor,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => GoRouter.of(context).pop(),
                              icon: const Icon(
                                Icons.arrow_back_ios_new_rounded,
                                color: Colors.white,
                                size: 22,
                              ),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(),
                            ),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  widget.specialtyName,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const Text(
                                  "Specialists",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white.withAlpha(26),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            widget.specialtyIcon,
                            color: Colors.white,
                            size: 28,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Container(
                      height: 45,
                      width: double.infinity,
                      child: SearchInput(
                        placeholder: "Search doctors...",
                        handleSearchAction: (value) {
                          setState(() {
                            _searchQuery = value;
                          });
                          _log.info("Searching for doctors: $value");
                        },
                      ),
                    ),
                  ],
                ),
              ),

              // Doctors List
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 32, 24, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Available Doctors",
                      style: TextStyle(
                        color: const Color.fromARGB(255, 0, 0, 0),
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 24),
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _filteredDoctors.length,
                      itemBuilder: (context, index) {
                        final doctor = _filteredDoctors[index];
                        return GestureDetector(
                          onTap: () {
                            context.push('/home/doctor-details', extra: {
                              'name': doctor["name"],
                              'image': doctor["image"],
                              'specialty': widget.specialtyName,
                              'rating': doctor["rating"].toString(),
                              'experience': doctor["experience"],
                              'about': "Dr. ${doctor["name"]} is a highly experienced ${widget.specialtyName} specialist with over ${doctor["experience"]} of practice. They have treated more than ${doctor["patients"]} patients and maintain a ${doctor["rating"]} rating based on patient reviews. Their expertise and dedication to patient care make them one of the most trusted doctors in their field.",
                              'location': "Cairo Medical Center",
                              'specialtyColor': widget.specialtyColor,
                            });
                          },
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 20),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Colors.white,
                                  widget.specialtyColor.withAlpha(13),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: widget.specialtyColor.withAlpha(26),
                                  blurRadius: 15,
                                  offset: const Offset(0, 8),
                                ),
                              ],
                              border: Border.all(
                                color: widget.specialtyColor.withAlpha(26),
                                width: 1,
                              ),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Row(
                                children: [
                                  CircleAvatar(
                                    radius: 30,
                                    backgroundImage: AssetImage(doctor["image"]),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          doctor["name"],
                                          style: TextStyle(
                                            color: palette.textDark,
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.star_rounded,
                                              color: Colors.amber,
                                              size: 16,
                                            ),
                                            const SizedBox(width: 4),
                                            Text(
                                              doctor["rating"].toString(),
                                              style: TextStyle(
                                                color: palette.textDark,
                                                fontSize: 14,
                                              ),
                                            ),
                                            const SizedBox(width: 12),
                                            Icon(
                                              Icons.work_outline_rounded,
                                              color: palette.textLight,
                                              size: 16,
                                            ),
                                            const SizedBox(width: 4),
                                            Text(
                                              doctor["experience"],
                                              style: TextStyle(
                                                color: palette.textLight,
                                                fontSize: 14,
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 4),
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.people_outline_rounded,
                                              color: palette.textLight,
                                              size: 16,
                                            ),
                                            const SizedBox(width: 4),
                                            Text(
                                              "${doctor["patients"]} patients",
                                              style: TextStyle(
                                                color: palette.textLight,
                                                fontSize: 14,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    onPressed: () {
                                      _log.info("Book appointment with ${doctor["name"]}");
                                    },
                                    icon: Icon(
                                      Icons.calendar_month_rounded,
                                      color: widget.specialtyColor,
                                      size: 24,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
} 