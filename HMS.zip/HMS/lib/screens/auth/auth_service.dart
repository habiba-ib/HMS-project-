import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'package:logging/logging.dart';

Logger _log = Logger('auth_service.dart');

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Sign up with email and password
  Future<UserCredential?> signUp(
      Function(String e) errorCallback,
      String fullName,
      String email,
      String password,
      String phoneNumber) async {
    try {
      final UserCredential credential =
          await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Get the current user
      final User? user = _auth.currentUser;

      // Check if user creation was successful
      if (user != null) {
        // Create a reference to the user's document in Firestore
        // final docRef = FirebaseFirestore.instance.collection('users').doc(user.uid);

        // Create user data map
        final userData = {
          'fullName': fullName,
          'email': email,
          'phoneNumber': phoneNumber,
          // Add any other relevant user data fields here
        };

        // Set the user data in Firestore
        // await docRef.set(userData);

        return credential; // Return the credential for further actions
      } else {
        return null; // Handle user creation failure (shouldn't happen)
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        errorCallback('The password provided is too weak.');
      } else if (e.code == 'email-already-in-use') {
        errorCallback('The account already exists for that email.');
      }
      return null;
    } catch (e) {
      _log.info(e);
      return null;
    }
  }

  // Sign in with email and password
  Future<UserCredential?> signIn(
      Function(String e) errorCallback, String email, String password) async {
    try {
      final UserCredential credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return credential;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        errorCallback('No user found for that email.');
      } else if (e.code == 'wrong-password') {
        errorCallback('Wrong password provided for that user.');
      } else {
        errorCallback(
            "The supplied auth credential is incorrect, malformed or has expired.");
      }
      return null;
    } catch (e) {
      _log.info(e);
      return null;
    }
  }

  // Sign out the current user
  Future<void> signOut() async {
    _log.info("Signing out...");
    await _auth.signOut();
  }

  // Check if a user is currently signed in
  Stream<User?> get currentUser => _auth.authStateChanges();
}
