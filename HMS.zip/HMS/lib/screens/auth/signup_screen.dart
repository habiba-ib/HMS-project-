import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:healthcare/notifiers/Is_doctor_notifier.dart';
import 'package:healthcare/notifiers/user_notifier.dart';
import 'package:healthcare/screens/auth/auth_service.dart';
import 'package:healthcare/styles/palette.dart';
import 'package:healthcare/utils/methods.dart';
import 'package:healthcare/widgets/custom_text_form_field.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

Logger _log = Logger('signup_screen.dart');

class _SignUpScreenState extends State<SignUpScreen> {
  final _formSignupKey = GlobalKey<FormState>();
  bool _obscurePassword = true;

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _phonenumberController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  AuthService authService = AuthService();

  @override
  Widget build(BuildContext context) {
    final palette = context.watch<Palette>();
    final bool isDoctor = context.watch<IsDoctorNotifier>().isDoctor;

    return Scaffold(
      backgroundColor: palette.backgroundMain,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Section
              Container(
                padding: const EdgeInsets.only(
                  left: 21,
                  right: 21,
                  top: 16,
                  bottom: 20,
                ),
                decoration: BoxDecoration(
                  color: palette.violet,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              "Create",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              "Account",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.medical_services_outlined,
                            color: Colors.white,
                            size: 26,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Text(
                      "Sign up to get started",
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),

              // Form Section
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 32, 24, 24),
                child: Form(
                  key: _formSignupKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Full Name Section
                      Text(
                        "Full Name",
                        style: TextStyle(
                          color: palette.textDark,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      CustomTextFormField(
                        controller: _fullNameController,
                        obscureText: false,
                        icon: null,
                        errorMessage: 'Please enter your full name',
                        hintText: 'Enter your full name',
                        prefixIcon: Icons.person_outline_rounded,
                      ),
                      const SizedBox(height: 24),

                      // Email Section
                      Text(
                        "Email Address",
                        style: TextStyle(
                          color: palette.textDark,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      CustomTextFormField(
                        controller: _emailController,
                        obscureText: false,
                        icon: null,
                        errorMessage: 'Please enter your email',
                        hintText: 'Enter your email',
                        prefixIcon: Icons.mail_outline_rounded,
                      ),
                      const SizedBox(height: 24),

                      // Phone Number Section
                      Text(
                        "Phone Number",
                        style: TextStyle(
                          color: palette.textDark,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      CustomTextFormField(
                        controller: _phonenumberController,
                        obscureText: false,
                        icon: null,
                        errorMessage: 'Please enter your phone number',
                        hintText: 'Enter your phone number',
                        prefixIcon: Icons.phone_android_rounded,
                      ),
                      const SizedBox(height: 24),

                      // Password Section
                      Text(
                        "Password",
                        style: TextStyle(
                          color: palette.textDark,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      CustomTextFormField(
                        controller: _passwordController,
                        obscureText: _obscurePassword,
                        icon: _obscurePassword ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                        errorMessage: 'Please enter your password',
                        hintText: 'Enter your password',
                        prefixIcon: Icons.lock_outline_rounded,
                      ),
                      const SizedBox(height: 32),

                      // Sign Up Button
                      Container(
                        width: double.infinity,
                        height: 50,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              palette.violet,
                              palette.violet.withOpacity(0.8),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(25),
                          boxShadow: [
                            BoxShadow(
                              color: palette.violet.withOpacity(0.3),
                              blurRadius: 15,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: () async {
                              if (_formSignupKey.currentState!.validate()) {
                                final UserCredential? userCredential = await authService.signUp(
                                  (error) {
                                    showErrorDialog(context, 'Sign Up Error', error);
                                  },
                                  _fullNameController.text,
                                  _emailController.text,
                                  _passwordController.text,
                                  _phonenumberController.text,
                                );
                                if (userCredential != null) {
                                  _log.info("Got user");
                                  if (!context.mounted) return;
                                  final userNotifier = Provider.of<UserNotifier>(context, listen: false);
                                  userNotifier.createUserFromFirebase(
                                    userCredential.user,
                                    isDoctor,
                                  );
                                  GoRouter.of(context).go("/home");
                                }
                              }
                            },
                            borderRadius: BorderRadius.circular(25),
                            child: const Center(
                              child: Text(
                                "Sign Up",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 32),

                      // Sign In Link
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Already have an account? ',
                            style: TextStyle(
                              color: palette.textFade,
                              fontSize: 14,
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              GoRouter.of(context).go("/auth");
                            },
                            child: Text(
                              'Sign In',
                              style: TextStyle(
                                color: palette.violet,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
