/// Use this inside the login process


/**
 * final Doctor doctor = Doctor(
              age: "32",
              gender: "Male",
              name: 'Dr. Aman Wins',
              email: 'wins@gmail.com',
              speciality: 'Cardiologists',
              location: 'Mars Hospital',
              image: 'assets/images/doctor-placeholder-appointment.png',
              rating: '5.0 (332 reviews)',
              experience: '11+',
              about:
                  'Dr. Carly Angel is the top most immunologists specialist in Crist Hospital in London, UK. She achived several awards for her wonderful contribution Read More. . . ',
              phoneNumber: '694525931',
              password: '123456789');

          context.read<UserNotifier>().setUser(doctor);
 * 
 */