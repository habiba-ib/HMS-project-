import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:healthcare/models/user.dart';
import 'package:healthcare/notifiers/user_notifier.dart';
import 'package:healthcare/utils/option_list.dart';
import 'package:healthcare/widgets/bottom_nav_bar.dart';
import 'package:healthcare/widgets/custom_inkwell.dart';
import 'package:healthcare/widgets/responsive_screen.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:healthcare/styles/palette.dart';
import 'package:healthcare/widgets/app_bar.dart';
import 'package:healthcare/widgets/search_input.dart';

class EditImagePage extends StatelessWidget {
  const EditImagePage({super.key});

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final palette = context.watch<Palette>();
    final User user = context.watch<UserNotifier>().getUser();

    return Scaffold(
      backgroundColor: palette.trueWhite,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(size.height * .29),
        child: CustomAppBar(
          topSpacing: 0,
          radius: 20,
          horizontalSpacing: 14,
          widthFactor: .558,
          fontSize: 20,
          title: "Edit Image",
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          top: 114,
          positionedWidget: SearchInput(
            topSpacing: 90,
            placeholder: "Search here...",
            handleSearchAction: () {},
          ),
          spacing: 0,
          bottomSpacing: 0,
        ),
      ),
      body: ResponsiveScreen(
          squarishMainArea: CircleAvatar(
            radius: 50.0,
            backgroundImage: AssetImage(user.image),
          ),
          rectangularMenuArea: Column(
            children: [
              CustomInkWell(
                 editImage: true,
                gallery:ImageSource.gallery,
                name: editImageOptionList[0]["name"].toString(),
                onTap: editImageOptionList[0]["onTap"].toString(),
                style: editImageOptionList[0]["style"] as TextStyle,
                icon: editImageOptionList[0]["icon"] as IconData,
              ),
              CustomInkWell(
                editImage: true,
                gallery:ImageSource.camera,
                name: editImageOptionList[1]["name"].toString(),
                onTap: editImageOptionList[1]["onTap"].toString(),
                style: editImageOptionList[1]["style"] as TextStyle,
                icon: editImageOptionList[1]["icon"] as IconData,
              ),
            ],
          )),
      bottomNavigationBar: const CustomBottomNavBar(
        page: 3,
      ),
    );
  }
}
