import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:healthcare/models/user.dart';
import 'package:healthcare/notifiers/user_notifier.dart';
import 'package:healthcare/styles/palette.dart';
import 'package:healthcare/widgets/bottom_nav_bar.dart';
import 'package:healthcare/widgets/custom_button.dart';
import 'package:healthcare/widgets/custom_text_form_field.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';

class PersonalDetails extends StatefulWidget {
  const PersonalDetails({super.key});

  @override
  State<PersonalDetails> createState() => _PersonalDetailsState();
}

class _PersonalDetailsState extends State<PersonalDetails> {
  static final _log = Logger('personal_details.dart');

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController usernameTextController = TextEditingController();
  final TextEditingController passwordTextController = TextEditingController();
  final TextEditingController phoneTextController = TextEditingController();
  final TextEditingController emailTextController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final palette = context.watch<Palette>();
    final user = context.watch<UserNotifier>().getUser();

    return Scaffold(
      backgroundColor: palette.backgroundMain,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Section
              Container(
                padding: const EdgeInsets.only(
                  left: 21,
                  right: 21,
                  top: 16,
                  bottom: 20,
                ),
                decoration: BoxDecoration(
                  color: palette.violet,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Edit",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const Text(
                              "Personal Details",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            IconButton(
                              onPressed: () {
                                _log.info("Going to notifications");
                                GoRouter.of(context).go('/home/notifications');
                              },
                              icon: const Icon(
                                Icons.notifications_outlined,
                                color: Colors.white,
                                size: 26,
                              ),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(),
                            ),
                            const SizedBox(width: 16),
                            GestureDetector(
                              onTap: () => GoRouter.of(context).go('/home/profile'),
                              child: CircleAvatar(
                                radius: 18,
                                backgroundImage: AssetImage(user.image),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Text(
                      "Update your personal information",
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),

              // Form Section
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 32, 24, 24),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Username Section
                      Text(
                        "Change Username",
                        style: TextStyle(
                          color: palette.textDark,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      CustomTextFormField(
                        controller: usernameTextController,
                        obscureText: false,
                        icon: null,
                        errorMessage: 'Please enter new name',
                        hintText: 'Enter new name',
                        prefixIcon: Icons.person_outline_rounded,
                      ),
                      const SizedBox(height: 24),

                      // Password Section
                      Text(
                        "Change Password",
                        style: TextStyle(
                          color: palette.textDark,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: CustomTextFormField(
                              controller: passwordTextController,
                              obscureText: true,
                              icon: Icons.visibility_off_rounded,
                              errorMessage: 'Please enter old password',
                              hintText: 'Old password',
                              prefixIcon: Icons.lock_outline_rounded,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: CustomTextFormField(
                              controller: passwordTextController,
                              obscureText: true,
                              icon: Icons.visibility_off_rounded,
                              errorMessage: 'Please enter new password',
                              hintText: 'New password',
                              prefixIcon: Icons.lock_outline_rounded,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),

                      // Phone Section
                      Text(
                        "Change Phone Number",
                        style: TextStyle(
                          color: palette.textDark,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      CustomTextFormField(
                        controller: phoneTextController,
                        obscureText: false,
                        icon: null,
                        errorMessage: 'Please enter valid phone number',
                        hintText: '+237 694 52 59 31',
                        prefixIcon: Icons.phone_android_rounded,
                      ),
                      const SizedBox(height: 24),

                      // Email Section
                      Text(
                        "Change Email Address",
                        style: TextStyle(
                          color: palette.textDark,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      CustomTextFormField(
                        controller: emailTextController,
                        obscureText: false,
                        icon: null,
                        errorMessage: 'Please enter valid email',
                        hintText: 'john@gmail.com',
                        prefixIcon: Icons.mail_outline_rounded,
                      ),
                      const SizedBox(height: 32),

                      // Save Button
                      Center(
                        child: Container(
                          width: 200,
                          height: 50,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                palette.violet,
                                palette.violet.withOpacity(0.8),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(25),
                            boxShadow: [
                              BoxShadow(
                                color: palette.violet.withOpacity(0.3),
                                blurRadius: 15,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () {
                                _log.info("Saving personal details changes");
                                // TODO: Implement save functionality
                              },
                              borderRadius: BorderRadius.circular(25),
                              child: const Center(
                                child: Text(
                                  "Save Changes",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: const CustomBottomNavBar(
        page: 3,
      ),
    );
  }
}
