import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:healthcare/styles/palette.dart';
import 'package:healthcare/widgets/search_input.dart';
import 'package:healthcare/notifiers/user_notifier.dart';
import 'package:provider/provider.dart';

class BookDoctorPage extends StatelessWidget {
  final String name;
  final String image;
  final String specialty;
  final String rating;
  final String experience;
  final String about;
  final String location;
  final Color specialtyColor;

  const BookDoctorPage({
    super.key,
    required this.name,
    required this.image,
    required this.specialty,
    required this.rating,
    required this.experience,
    required this.about,
    required this.location,
    required this.specialtyColor,
  });

  @override
  Widget build(BuildContext context) {
    final palette = context.watch<Palette>();
    final user = context.watch<UserNotifier>().getUser();
    final Size size = MediaQuery.of(context).size;

    // Selected appointment state
    String? selectedTime;
    String? selectedDate;

    // Sample available appointments data
    final List<Map<String, dynamic>> availableAppointments = [
      {
        "time": "09:00 AM",
        "date": "Today",
        "isAvailable": true,
      },
      {
        "time": "10:30 AM",
        "date": "Today",
        "isAvailable": true,
      },
      {
        "time": "02:00 PM",
        "date": "Today",
        "isAvailable": true,
      },
      {
        "time": "09:00 AM",
        "date": "Tomorrow",
        "isAvailable": true,
      },
      {
        "time": "11:00 AM",
        "date": "Tomorrow",
        "isAvailable": true,
      },
      {
        "time": "03:30 PM",
        "date": "Tomorrow",
        "isAvailable": true,
      },
    ];

    void showSuccessDialog() {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Container(
              padding: EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.check_circle_rounded,
                      color: Colors.green,
                      size: 32,
                    ),
                  ),
                  SizedBox(height: 20),
                  Text(
                    "Booking Confirmed!",
                    style: TextStyle(
                      color: palette.textDark,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 12),
                  Text(
                    "Your appointment has been successfully booked. You will receive a confirmation shortly.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: palette.textLight,
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      context.go('/home');
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: specialtyColor,
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      "Back to Home",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    }

    void showConfirmationDialog(String time, String date) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Container(
              padding: EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: specialtyColor.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.calendar_today_rounded,
                      color: specialtyColor,
                      size: 32,
                    ),
                  ),
                  SizedBox(height: 20),
                  Text(
                    "Confirm Appointment",
                    style: TextStyle(
                      color: palette.textDark,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 12),
                  Text(
                    "Are you sure you want to book an appointment with Dr. $name on $date at $time?",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: palette.textLight,
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text(
                          "Cancel",
                          style: TextStyle(
                            color: palette.textLight,
                            fontSize: 16,
                          ),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                          showSuccessDialog();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: specialtyColor,
                          foregroundColor: Colors.white,
                          padding: EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 12,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: Text(
                          "Confirm",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      );
    }

    return Scaffold(
      backgroundColor: palette.backgroundMain,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Section
              Container(
                padding: EdgeInsets.only(
                  left: 21,
                  right: 21,
                  top: 16,
                  bottom: 20,
                ),
                decoration: BoxDecoration(
                  color: specialtyColor,
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => context.pop(),
                              icon: Icon(
                                Icons.arrow_back_ios_new_rounded,
                                color: Colors.white,
                                size: 22,
                              ),
                              padding: EdgeInsets.zero,
                              constraints: BoxConstraints(),
                            ),
                            SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Book",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  "Doctor",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            IconButton(
                              onPressed: () {
                                // Handle share
                              },
                              icon: Icon(
                                Icons.share_rounded,
                                color: Colors.white,
                                size: 26,
                              ),
                              padding: EdgeInsets.zero,
                              constraints: BoxConstraints(),
                            ),
                            SizedBox(width: 16),
                            IconButton(
                              onPressed: () {
                                // Handle bookmark
                              },
                              icon: Icon(
                                Icons.bookmark_border_rounded,
                                color: Colors.white,
                                size: 26,
                              ),
                              padding: EdgeInsets.zero,
                              constraints: BoxConstraints(),
                            ),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    // Doctor Info Card
                    Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            blurRadius: 10,
                            offset: Offset(0, 5),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 30,
                            backgroundImage: AssetImage(image),
                          ),
                          SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Dr. $name",
                                  style: TextStyle(
                                    color: palette.textDark,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  specialty,
                                  style: TextStyle(
                                    color: palette.textLight,
                                    fontSize: 14,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.location_on_outlined,
                                      color: palette.textLight,
                                      size: 16,
                                    ),
                                    SizedBox(width: 4),
                                    Text(
                                      location,
                                      style: TextStyle(
                                        color: palette.textLight,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: specialtyColor.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.star_rounded,
                                  color: specialtyColor,
                                  size: 16,
                                ),
                                SizedBox(width: 4),
                                Text(
                                  rating,
                                  style: TextStyle(
                                    color: specialtyColor,
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Stats Section
              Padding(
                padding: EdgeInsets.fromLTRB(24, 24, 24, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildStatItem(
                      context,
                      Icons.work_outline_rounded,
                      "$experience Years",
                      "Experience",
                      specialtyColor,
                    ),
                    _buildStatItem(
                      context,
                      Icons.people_outline_rounded,
                      "1.2k+",
                      "Patients",
                      specialtyColor,
                    ),
                    _buildStatItem(
                      context,
                      Icons.star_outline_rounded,
                      "4.8",
                      "Rating",
                      specialtyColor,
                    ),
                  ],
                ),
              ),

              // About Section
              Padding(
                padding: EdgeInsets.fromLTRB(24, 24, 24, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "About",
                      style: TextStyle(
                        color: palette.textDark,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      about,
                      style: TextStyle(
                        color: palette.textLight,
                        fontSize: 14,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),

              // Available Appointments Section
              Padding(
                padding: EdgeInsets.fromLTRB(24, 32, 24, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Available Appointments",
                      style: TextStyle(
                        color: palette.textDark,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 16),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 1.5,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                      ),
                      itemCount: availableAppointments.length,
                      itemBuilder: (context, index) {
                        final appointment = availableAppointments[index];
                        final isSelected = selectedTime == appointment["time"] && 
                                           selectedDate == appointment["date"];
                        return GestureDetector(
                          onTap: () {
                            selectedTime = appointment["time"];
                            selectedDate = appointment["date"];
                            showConfirmationDialog(
                              appointment["time"],
                              appointment["date"],
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  isSelected ? specialtyColor : Colors.white,
                                  isSelected 
                                    ? specialtyColor.withOpacity(0.8)
                                    : specialtyColor.withOpacity(0.05),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: specialtyColor.withOpacity(0.1),
                                  blurRadius: 15,
                                  offset: Offset(0, 8),
                                ),
                              ],
                              border: Border.all(
                                color: isSelected 
                                  ? specialtyColor 
                                  : specialtyColor.withOpacity(0.1),
                                width: isSelected ? 2 : 1,
                              ),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  appointment["time"],
                                  style: TextStyle(
                                    color: isSelected 
                                      ? Colors.white 
                                      : palette.textDark,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  appointment["date"],
                                  style: TextStyle(
                                    color: isSelected 
                                      ? Colors.white.withOpacity(0.8)
                                      : palette.textLight,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatItem(
    BuildContext context,
    IconData icon,
    String value,
    String label,
    Color color,
  ) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: color,
            size: 24,
          ),
        ),
        SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 12,
          ),
        ),
      ],
    );
  }
} 