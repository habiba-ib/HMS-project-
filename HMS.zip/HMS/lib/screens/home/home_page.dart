import 'package:flutter/material.dart';
import 'package:healthcare/models/user.dart';
import 'package:healthcare/notifiers/user_notifier.dart';
import 'package:healthcare/styles/palette.dart';
import 'package:healthcare/widgets/bottom_nav_bar.dart';
import 'package:healthcare/widgets/category.dart';
import 'package:healthcare/widgets/search_input.dart';
import 'package:healthcare/utils/current_appointments_list.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static final _log = Logger('home_page.dart');
  String _searchQuery = '';

  List<Map<String, dynamic>> get _filteredAppointments {
    if (_searchQuery.isEmpty) {
      return currentAppointmentsList;
    }
    return currentAppointmentsList.where((appointment) {
      return appointment['name'].toString().toLowerCase().contains(_searchQuery.toLowerCase()) ||
             appointment['specialization'].toString().toLowerCase().contains(_searchQuery.toLowerCase());
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final palette = context.watch<Palette>();
    User user = context.watch<UserNotifier>().getUser();
    final Size size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: palette.backgroundMain,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Section
              Container(
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                decoration: BoxDecoration(
                  color: palette.violet,
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Welcome back,",
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.8),
                                fontSize: 16,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              user.name,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            IconButton(
                              onPressed: () {
                                _log.info("Going to notifications");
                                GoRouter.of(context).go('/home/notifications');
                              },
                              icon: Icon(Icons.notifications_outlined, 
                                color: Colors.white,
                                size: 26,
                              ),
                              padding: EdgeInsets.zero,
                              constraints: BoxConstraints(),
                            ),
                            SizedBox(width: 16),
                            GestureDetector(
                              onTap: () => GoRouter.of(context).go('/home/profile'),
                              child: CircleAvatar(
                                radius: 18,
                                backgroundImage: AssetImage(user.image),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(height: 24),
                    Container(
                      height: 45,
                      width: double.infinity,
                      child: SearchInput(
                        placeholder: "Search doctors, appointments...",
                        handleSearchAction: (value) {
                          setState(() {
                            _searchQuery = value;
                          });
                          _log.info("Searching for doctors and appointments: $value");
                        },
                      ),
                    ),
                  ],
                ),
              ),

              // Quick Stats Section
              Padding(
                padding: EdgeInsets.all(24),
                child: _buildHealthStatusCard(context, palette),
              ),

              // Services Grid
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Services",
                          style: TextStyle(
                            color: palette.textDark,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: palette.violet.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            "View All",
                            style: TextStyle(
                              color: palette.violet,
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    _buildServiceCard(
                      context,
                      user.role == "DOCTOR" ? "Your Appointments" : "Today's Appointments",
                      "/home/appointments",
                      Icons.calendar_month_rounded,
                      "Schedule and manage your medical appointments",
                      palette,
                    ),
                    _buildServiceCard(
                      context,
                      user.role == "DOCTOR" ? "Your Biography" : "Payment",
                      user.role == "DOCTOR" ? "/home/appointments/my-appointment" : "/home/payment",
                      user.role == "DOCTOR" ? Icons.person_outline_rounded : Icons.payment_rounded,
                      user.role == "DOCTOR" ? "View and update your professional profile" : "Manage your payments and transactions",
                      palette,
                    ),
                    _buildServiceCard(
                      context,
                      user.role == "DOCTOR" ? "Diagnostics & Treatment" : "Prescriptions & Medication",
                      "/home/prescriptions",
                      user.role == "DOCTOR" ? Icons.medical_services_rounded : Icons.medication_liquid_rounded,
                      user.role == "DOCTOR" ? "Access patient diagnostics and treatment plans" : "View and manage your prescriptions and medications",
                      palette,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: const CustomBottomNavBar(
        page: 0,
      ),
    );
  }

  Widget _buildServiceCard(BuildContext context, String title, String route, IconData icon, String subtitle, Palette palette) {
    return GestureDetector(
      onTap: () => GoRouter.of(context).go(route),
      child: Container(
        margin: EdgeInsets.only(bottom: 16),
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.white,
              palette.violet.withOpacity(0.05),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: palette.violet.withOpacity(0.1),
              blurRadius: 15,
              offset: Offset(0, 8),
            ),
          ],
          border: Border.all(
            color: palette.violet.withOpacity(0.1),
            width: 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    palette.violet.withOpacity(0.1),
                    palette.violet.withOpacity(0.2),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(
                icon,
                size: 32,
                color: palette.violet,
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: palette.textDark,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: palette.textFade,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios_rounded,
              color: palette.violet.withOpacity(0.5),
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHealthStatusCard(BuildContext context, Palette palette) {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            palette.darkViolet,
            palette.violet,
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: palette.darkViolet.withOpacity(0.3),
            blurRadius: 15,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            Colors.white.withOpacity(0.2),
                            Colors.white.withOpacity(0.3),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        Icons.health_and_safety_rounded,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        "Your Health Status",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 12),
                Text(
                  "Track your appointments and medical records in one place",
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 14,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(width: 16),
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 10,
                  offset: Offset(0, 5),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(40),
              child: Image.asset(
                'assets/images/doctor-woman-looking.png',
                fit: BoxFit.cover,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
