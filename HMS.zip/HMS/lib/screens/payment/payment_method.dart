import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:healthcare/styles/palette.dart';
import 'package:healthcare/widgets/custom_button.dart';
import 'package:healthcare/widgets/payment_method_button.dart';
import 'package:healthcare/notifiers/user_notifier.dart';
import 'package:healthcare/widgets/search_input.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';

class PaymentMethodPage extends StatelessWidget {
  const PaymentMethodPage({super.key});

  static final _log = Logger('payment_method.dart');

  @override
  Widget build(BuildContext context) {
    final palette = context.watch<Palette>();
    final user = context.watch<UserNotifier>().getUser();
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: palette.backgroundMain,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Section
              Container(
                padding: EdgeInsets.only(
                  left: 21,
                  right: 21,
                  top: 16,
                  bottom: 20,
                ),
                decoration: BoxDecoration(
                  color: palette.violet,
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => GoRouter.of(context).pop(),
                              icon: Icon(
                                Icons.arrow_back_ios_new_rounded,
                                color: Colors.white,
                                size: 22,
                              ),
                              padding: EdgeInsets.zero,
                              constraints: BoxConstraints(),
                            ),
                            SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Payment",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  "Method",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            IconButton(
                              onPressed: () {
                                _log.info("Going to notifications");
                                GoRouter.of(context).go('/home/notifications');
                              },
                              icon: Icon(
                                Icons.notifications_outlined,
                                color: Colors.white,
                                size: 26,
                              ),
                              padding: EdgeInsets.zero,
                              constraints: BoxConstraints(),
                            ),
                            SizedBox(width: 16),
                            GestureDetector(
                              onTap: () => GoRouter.of(context).go('/home/profile'),
                              child: CircleAvatar(
                                radius: 18,
                                backgroundImage: AssetImage(user.image),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    Container(
                      height: 45,
                      width: double.infinity,
                      child: SearchInput(
                        placeholder: "Search payment methods...",
                        handleSearchAction: (value) {
                          _log.info("Searching for payment methods");
                        },
                      ),
                    ),
                 
                  ],
                ),
              ),

              // Payment Methods Section
              Padding(
                padding: EdgeInsets.fromLTRB(24, 32, 24, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Payment Methods",
                          style: TextStyle(
                            color: palette.textDark,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            color: palette.violet.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            "View All",
                            style: TextStyle(
                              color: palette.violet,
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 24),
                    PaymentButton(
                      highlightColor: palette.trueWhite,
                      onTap: () {
                        GoRouter.of(context).go("/home/payment/mtn");
                      },
                      image: 'assets/images/mtn-mobile-money.png',
                      moneyType: "Mobile Money",
                      color: palette.trueWhite,
                      backColor: palette.mtn,
                      fontSize: 16,
                      heightBtn: 70,
                    ),
                    SizedBox(height: 16),
                    PaymentButton(
                      highlightColor: palette.trueWhite,
                      onTap: () {
                        GoRouter.of(context).go("/home/payment/orange");
                      },
                      image: 'assets/images/orange-money.png',
                      moneyType: "Orange Money",
                      color: palette.textDark,
                      backColor: palette.orange,
                      fontSize: 16,
                      heightBtn: 70,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
